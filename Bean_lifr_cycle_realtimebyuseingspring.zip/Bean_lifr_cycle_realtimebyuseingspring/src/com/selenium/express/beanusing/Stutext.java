package com.selenium.express.beanusing;

import java.sql.SQLException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Stutext {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		ApplicationContext context =new ClassPathXmlApplicationContext("beans.xml");
		StudentDao std=context.getBean("std",StudentDao.class);
		std.SelectallRows();
		
		


	}

}
