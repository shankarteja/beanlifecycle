package com.selenium.express.beanusing;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.context.annotation.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


public class StudentDao {


	private String driver;
	private String url;
	private String username;
	private String password;


	Connection con;

	public String getDriver() {
		return driver;
	}

	public void setDriver(String driver) {
		this.driver = driver;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	
	@PostConstruct
	public void createstudnetdbconnection() throws ClassNotFoundException, SQLException {
		Class.forName(driver);
		 con=DriverManager.getConnection(url,username,password);

	}

	public void SelectallRows() throws ClassNotFoundException, SQLException {

		//		Class.forName(driver);												 
		//		Connection con=DriverManager.getConnection(url,username,password);
	//	createstudnetdbconnection();

		Statement stmt=con.createStatement();
		ResultSet rst=stmt.executeQuery("SELECT * FROM userapp.fooditem");
		while(rst.next()) {
			int fon=rst.getInt(1);
			String fname=rst.getString(2);
			float fprice=rst.getFloat(3);
			System.out.println(fon+"  "+fname+"  "+fprice);
		}
		con.close();
	}

	public void deletestudentrecord(int fon) throws ClassNotFoundException, SQLException {


		//		Class.forName(driver);
		//		Connection con=DriverManager.getConnection(url,username,password);


		Statement stmt=con.createStatement();
		stmt.executeUpdate(" delete  FROM userapp.fooditem where fon = " + fon);
		System.out.println("Record deleted the data fon= "+ fon);
		con.close();


	}




}
